import { type RouteConfig, index, layout, route } from "@react-router/dev/routes";

export default [
  index("routes/landing.tsx"),
...(process.env.NODE_ENV !== "production" && process.env.EIC_LOCAL_DISCOVER_PREVIEW === "1" ? [route("discover-local-preview", "routes/discover-local-preview.tsx")] : []),

  layout("layouts/desktop.tsx", [
    route("feed", "routes/feed.tsx"),
    route("market", "routes/market.tsx"),
    route("compose", "routes/compose.tsx"),
    route("draw", "routes/draw.tsx"),
    route("connections", "routes/connections.tsx"),
    route("graph", "routes/graph.tsx"),
    route("chat/:authorId", "routes/chat.tsx"),
    route("profile", "routes/profile.tsx"),
    route("profile/:authorId", "routes/profile.tsx", { id: "profile-author" }),
    route("tools", "routes/tools.tsx"),
    route("tools/journal", "routes/journal.tsx"),
    route("tools/music", "routes/music.tsx"),
    route("tools/calendar", "routes/calendar.tsx"),
    route("tools/chores", "routes/chores.tsx"),
    route("vault", "routes/vault.tsx"),
    route("item/:id", "routes/item.tsx"),
  ]),
  route("stickers", "routes/stickers.tsx"),
  route("music-library", "routes/music-library.tsx"),
  route("learn-piano", "routes/learn-piano.tsx"),
  route("unlock", "routes/unlock.tsx"),
  // Read-only shared-post view sits outside the desktop layout: reading a shared link
  // must not require a vault. Saving prompts for one explicitly.
  route("shared/:id", "routes/shared.tsx"),
  route("*", "routes/not-found.tsx"),
  route("showcase", "routes/home.tsx"),
] satisfies RouteConfig;
